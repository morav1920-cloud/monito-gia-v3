import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  boolean,
  json,
  bigint,
} from "drizzle-orm/mysql-core";
import type { StoredContent } from "../contracts/monito";
import type { CurriculumAnchor } from "../contracts/curriculum";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Actividad generada por el motor (MonitoSchema v2 empaquetado) */
export const activities = mysqlTable("activities", {
  id: serial("id").primaryKey(),
  teacherId: bigint("teacherId", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  subject: varchar("subject", { length: 60 }).notNull().default("matematicas"),
  grade: int("grade").notNull(),
  seedQuestion: text("seedQuestion").notNull(),
  learningGoal: varchar("learningGoal", { length: 500 }),
  status: mysqlEnum("status", ["draft", "published"])
    .default("draft")
    .notNull(),
  /** Código corto para que los alumnos entren a jugar */
  shareCode: varchar("shareCode", { length: 12 }).notNull().unique(),
  /** ai = generada por el motor; clone = clonada de la biblioteca */
  origin: mysqlEnum("origin", ["ai", "clone"]).default("ai").notNull(),
  /** Si es clon, id de la actividad de la biblioteca de donde salió */
  clonedFromId: bigint("clonedFromId", { mode: "number", unsigned: true }),
  /** Visible en la biblioteca global comunitaria */
  isSharedToLibrary: boolean("isSharedToLibrary").default(false).notNull(),
  /** Veces que otros docentes la han clonado */
  libraryClones: int("libraryClones").default(0).notNull(),
  /** Arquetipo de micro-app (FK lógica a app_templates.formatId) */
  formatId: varchar("formatId", { length: 40 })
    .notNull()
    .default("multiple_choice"),
  /** Anclaje curricular oficial NEM/CONALITEG (campo formativo + PDA) */
  curriculumAnchor: json("curriculumAnchor").$type<CurriculumAnchor>(),
  /** Contenido MonitoSchema v2 completo (estructura según formatId) */
  content: json("content").$type<StoredContent>().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = typeof activities.$inferInsert;

/** Sesión de juego de un alumno (sin cuenta; alias efímero) */
export const playSessions = mysqlTable("play_sessions", {
  id: serial("id").primaryKey(),
  activityId: bigint("activityId", { mode: "number", unsigned: true }).notNull(),
  studentAlias: varchar("studentAlias", { length: 60 }).notNull(),
  correctCount: int("correctCount").notNull().default(0),
  totalAnswered: int("totalAnswered").notNull().default(0),
  maxScaffoldUsed: int("maxScaffoldUsed").notNull().default(0),
  finishedAt: timestamp("finishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PlaySession = typeof playSessions.$inferSelect;
export type InsertPlaySession = typeof playSessions.$inferInsert;

/** Respuesta individual a un reactivo (evento analítico con taxonomía) */
export const responses = mysqlTable("responses", {
  id: serial("id").primaryKey(),
  sessionId: bigint("sessionId", { mode: "number", unsigned: true }).notNull(),
  reactivoId: varchar("reactivoId", { length: 60 }).notNull(),
  selectedOptionId: varchar("selectedOptionId", { length: 10 }).notNull(),
  isCorrect: boolean("isCorrect").notNull(),
  /** null cuando la respuesta es correcta */
  errorCode: varchar("errorCode", { length: 10 }),
  /** Peldaño de andamiaje más alto consultado (0 = ninguno) */
  scaffoldLevel: int("scaffoldLevel").notNull().default(0),
  timeMs: int("timeMs").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Response = typeof responses.$inferSelect;
export type InsertResponse = typeof responses.$inferInsert;

/** Monedero de créditos de IA por docente */
export const creditWallets = mysqlTable("credit_wallets", {
  userId: bigint("userId", { mode: "number", unsigned: true }).primaryKey(),
  balance: int("balance").notNull().default(0),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type CreditWallet = typeof creditWallets.$inferSelect;

/** Movimiento de créditos (positivo = abono, negativo = cargo) */
export const creditTransactions = mysqlTable("credit_transactions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  amount: int("amount").notNull(),
  reason: varchar("reason", { length: 40 }).notNull(),
  /** Actividad relacionada, si aplica */
  activityId: bigint("activityId", { mode: "number", unsigned: true }),
  /** Saldo resultante después del movimiento */
  balanceAfter: int("balanceAfter").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CreditTransaction = typeof creditTransactions.$inferSelect;

/**
 * Plantilla utilitaria (arquetipo de micro-app). Catálogo extensible:
 * el administrador registra nuevos formatos y el motor MGAA los adopta
 * vía few-shot prompting dinámico.
 */
export const appTemplates = mysqlTable("app_templates", {
  id: serial("id").primaryKey(),
  /** Identificador único de formato: multiple_choice, flashcards… */
  formatId: varchar("formatId", { length: 40 }).notNull().unique(),
  name: varchar("name", { length: 120 }).notNull(),
  icon: varchar("icon", { length: 40 }).notNull().default("blocks"),
  description: text("description").notNull(),
  /** Cuándo es pedagógicamente idóneo este formato */
  pedagogicFit: text("pedagogicFit").notNull(),
  /** Few-shot: ejemplo compacto de contenido JSON válido para este formato */
  exampleJson: text("exampleJson").notNull(),
  /** Qué evalúa el QA automático para este formato */
  qaRules: text("qaRules").notNull(),
  /** Formatos integrados no se pueden eliminar ni editar */
  isBuiltin: boolean("isBuiltin").default(false).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdBy: bigint("createdBy", { mode: "number", unsigned: true }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AppTemplate = typeof appTemplates.$inferSelect;
export type InsertAppTemplate = typeof appTemplates.$inferInsert;

/**
 * Base de conocimiento curricular oficial — NEM fase 4 (3° a 6° primaria).
 * Cada entrada representa un contenido del Plan de Estudios 2022 con su
 * proceso de desarrollo de aprendizaje (PDA), indexada para el cruce
 * semántico-léxico con las semillas docentes.
 */
export const curriculumEntries = mysqlTable("curriculum_entries", {
  id: serial("id").primaryKey(),
  /** Campo formativo NEM */
  campoFormativo: mysqlEnum("campoFormativo", [
    "lenguajes",
    "saberes_pensamiento",
    "etica_naturaleza",
    "humano_comunitario",
  ]).notNull(),
  grade: int("grade").notNull(), // 3-6
  /** Asignatura / área de conocimiento oficial */
  asignatura: varchar("asignatura", { length: 60 }).notNull(),
  /** Título del contenido oficial */
  contenido: varchar("contenido", { length: 500 }).notNull(),
  /** Proceso de desarrollo de aprendizaje (PDA / aprendizaje esperado) */
  pda: text("pda").notNull(),
  /** Palabras clave para el índice léxico (separadas por comas) */
  keywords: text("keywords").notNull(),
});

export type CurriculumEntry = typeof curriculumEntries.$inferSelect;
export type InsertCurriculumEntry = typeof curriculumEntries.$inferInsert;
