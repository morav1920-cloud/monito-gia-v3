import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery } from "./middleware";
import {
  cloneActivity,
  findLibraryMatches,
  listSharedActivities,
  setLibraryShared,
  type LibraryMatch,
} from "./queries/library";
import { findActivityById } from "./queries/activities";
import { countReactivos } from "@contracts/monito";

function toCard(a: Awaited<ReturnType<typeof listSharedActivities>>[number]) {
  return {
    id: a.id,
    title: a.title,
    grade: a.grade,
    subject: a.subject,
    seedQuestion: a.seedQuestion,
    learningGoal: a.learningGoal,
    libraryClones: a.libraryClones,
    formatId: a.formatId,
    campoFormativo: a.curriculumAnchor?.campoFormativo ?? null,
    reactivosCount: countReactivos(a.content),
    zdpEstimada: a.content.meta.zdpEstimada,
    isMine: false as boolean,
  };
}

export const libraryRouter = createRouter({
  /** Explora la biblioteca comunitaria (actividades compartidas) */
  browse: authedQuery
    .input(
      z.object({
        q: z.string().max(200).optional(),
        grade: z.number().int().min(3).max(6).optional(),
      }),
    )
    .query(async ({ ctx, input }) => {
      const rows = await listSharedActivities({
        q: input.q,
        grade: input.grade,
        limit: 60,
      });
      return rows.map((a) => ({
        ...toCard(a),
        isMine: a.teacherId === ctx.user.id,
      }));
    }),

  /**
   * Emparejamiento semilla ↔ biblioteca. El frontend lo consulta
   * antes de gastar créditos en una generación original.
   */
  match: authedQuery
    .input(
      z.object({
        seedQuestion: z.string().min(10).max(2000),
        grade: z.number().int().min(3).max(6),
      }),
    )
    .mutation(async ({ ctx, input }): Promise<{
      strong: LibraryMatch[];
      candidates: LibraryMatch[];
    }> => {
      return findLibraryMatches(
        input.seedQuestion,
        input.grade,
        ctx.user.id,
      );
    }),

  /** Clona una actividad compartida — costo cero de tokens */
  clone: authedQuery
    .input(z.object({ sourceId: z.number().int() }))
    .mutation(async ({ ctx, input }) => {
      const insertId = await cloneActivity(input.sourceId, ctx.user.id);
      if (!insertId)
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "NOT_CLONABLE",
        });
      const activity = await findActivityById(insertId);
      if (!activity) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      return activity;
    }),

  /** Comparte (o retira) una actividad propia en la biblioteca */
  setShared: authedQuery
    .input(z.object({ id: z.number().int(), shared: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const result = await setLibraryShared(
        input.id,
        ctx.user.id,
        input.shared,
      );
      if (!result.ok)
        throw new TRPCError({
          code: "BAD_REQUEST",
          message:
            result.reason === "not_published"
              ? "NOT_PUBLISHED"
              : "NOT_FOUND",
        });
      return { ok: true };
    }),
});
