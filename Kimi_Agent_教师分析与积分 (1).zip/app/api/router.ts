import { authRouter } from "./auth-router";
import { activitiesRouter } from "./activities-router";
import { playRouter } from "./play-router";
import { analyticsRouter } from "./analytics-router";
import { creditsRouter } from "./credits-router";
import { libraryRouter } from "./library-router";
import { templatesRouter } from "./templates-router";
import { curriculumRouter } from "./curriculum-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  activities: activitiesRouter,
  play: playRouter,
  analytics: analyticsRouter,
  credits: creditsRouter,
  library: libraryRouter,
  templates: templatesRouter,
  curriculum: curriculumRouter,
});

export type AppRouter = typeof appRouter;
