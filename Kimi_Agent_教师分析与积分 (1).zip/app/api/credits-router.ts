import { CREDIT_COSTS, WELCOME_CREDITS, CREDIT_REASON_LABEL, type CreditReason } from "@contracts/credits";
import { createRouter, authedQuery } from "./middleware";
import { getOrCreateWallet, listTransactions } from "./queries/credits";

export const creditsRouter = createRouter({
  /** Saldo actual + tabla de costos (crea el monedero con bono si no existe) */
  wallet: authedQuery.query(async ({ ctx }) => {
    const wallet = await getOrCreateWallet(ctx.user.id);
    return {
      balance: wallet.balance,
      costs: CREDIT_COSTS,
      welcomeCredits: WELCOME_CREDITS,
    };
  }),

  /** Historial de movimientos recientes */
  history: authedQuery.query(async ({ ctx }) => {
    const txs = await listTransactions(ctx.user.id, 30);
    return txs.map((t) => ({
      id: t.id,
      amount: t.amount,
      reason: t.reason as CreditReason,
      reasonLabel:
        CREDIT_REASON_LABEL[t.reason as CreditReason] ?? t.reason,
      activityId: t.activityId,
      balanceAfter: t.balanceAfter,
      createdAt: t.createdAt,
    }));
  }),
});
