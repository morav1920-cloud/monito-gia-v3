import { generateObject } from "ai";
import {
  monitoContentSchema,
  getContentSchema,
  type StoredContent,
  type MonitoContent,
  type FlashcardsContent,
  type FlowchartContent,
  ERROR_CODES,
} from "@contracts/monito";
import { z } from "zod";
import { kimiGw } from "./provider";
import { classifyAiError, listModels } from "./ai-client";
import { CAMPO_META, type CurriculumAnchor } from "@contracts/curriculum";
import type { AppTemplate } from "@db/schema";

/**
 * Motor de Generación Automática de Actividades (MGAA) — Monito gIA v3.0
 * Matriz Polivalente: el contenido se adapta al arquetipo seleccionado
 * (quiz diagnóstico, flashcards, secuencias…) con few-shot dinámico
 * inyectado desde la plantilla registrada en la base de datos.
 *
 * Pilares pedagógicos intactos en TODOS los formatos:
 *  ZDP + andamiaje · taxonomía de errores · feedback Dweck · offline-first
 */

/* ---------- Prompt base compartido por todos los arquetipos ---------- */

const PEDAGOGY_CORE = `Eres el Motor de Generación de Actividades de "Monito gIA", plataforma educativa mexicana para primaria (3° a 6°). Combinas psicología educativa sociocultural (Vygotsky: ZDP; Piaget; Dweck: mentalidad de crecimiento) con diseño instruccional SEP.

REGLAS INQUEBRANTABLES EN CUALQUIER FORMATO:
- Contextos cercanos a la vida de un niño mexicano de primaria (mercado, tienda, feria, escuela, mascotas). Nombres mexicanos variados.
- Lenguaje claro, frases cortas, adecuado al grado. Datos y hechos CORRECTOS.
- Retroalimentación Dweck: valida el esfuerzo, nombra la estrategia, propone un cambio de perspectiva. JAMÁS lenguaje punitivo, comparativo o de juicio fijo.
- Nada revela la respuesta directamente: las pistas guían el pensamiento.

Devuelve ÚNICAMENTE el objeto JSON conforme al esquema.`;

/* ---------- Arquetipo: opción múltiple diagnóstica ---------- */

const QUIZ_RULES = `REACTIVOS:
- Genera entre 2 y 4 reactivos isomorfos: mismo constructo que la semilla, contextos y números variados.
- Números razonables para el grado: 3° hasta centenas simples; 4° hasta millares y fracciones simples; 5°-6° decimales, fracciones y operaciones de varios dígitos.

OPCIONES (exactamente 4, ids "a","b","c","d"):
- Exactamente UNA correcta. Los 3 distractores son PLAUSIBLES: cada uno nace de un error real y frecuente de niños de ese grado. Nunca valores absurdos ni "todas las anteriores".
- Cada distractor lleva su errorCode de la taxonomía:
  * CONCEPT = error conceptual (no comprende el concepto)
  * PROC = error procedimental (falla un paso del algoritmo)
  * ATTN = despiste (usa el primer número que ve, omite un dato)
  * READ = comprensión lectora (opera bien pero responde otra cosa)
  * GUESS = opción atractiva sin relación lógica (detecta azar)
- Usa al menos 2 códigos distintos entre los 3 distractores. En la correcta errorCode y diagnostico son null.
- "diagnostico": frase pedagógica para el DOCENTE explicando qué razonamiento produce ese distractor.

ANDAMIAJE (exactamente 5 peldaños por reactivo, niveles 1 a 5 en orden):
1. activacion — reconecta con algo que el alumno ya sabe
2. reencuadre — reformula el problema con otras palabras o un dibujo mental
3. estrategia — sugiere un MÉTODO concreto sin aplicarlo
4. descomposicion — divide el problema en sub-pasos con preguntas guía
5. analogo_resuelto — resuelve PASO A PASO un problema SIMILAR con números distintos; JAMÁS el original
- PROHIBIDO revelar la respuesta correcta en cualquier peldaño, incluido el 5.

RETROALIMENTACIÓN:
- feedbackPorError: un mensaje por cada código usado en los distractores del reactivo. Estructura: (a) valida el esfuerzo, (b) nombra la estrategia probable ("parece que..."), (c) belief shift accionable.
- feedbackCorrecto: celebra la ESTRATEGIA y el ESFUERZO, nunca la inteligencia.
- mensajeCierre: refuerza que el error es información, no fracaso.

META: titulo corto (máx. 8 palabras), aprendizajeEsperado alineado al SEP, zdpEstimada según la distancia semilla-grado.`;

/* ---------- Arquetipos compactos (reglas propias) ---------- */

const FLASHCARDS_RULES = `TARJETAS (6 a 10):
- Todas sobre el MISMO tema que la semilla, ampliándolo con cobertura equilibrada.
- frente: corto (1-5 palabras o una pregunta directa). reverso: corto, exacto y verificable.
- pista: gancho socrático (imagen mental, rima, pista contextual) que NO contenga el reverso.
- errorTipico: código de taxonomía del error más probable al recordar (CONCEPT/ATTN/READ…) o null.
- Sin tarjetas duplicadas, sin pares triviales entre sí. Dificultad creciente.

META: titulo corto, aprendizajeEsperado SEP, zdpEstimada (memorizar suele ser baja/media).`;

const FLOWCHART_RULES = `SECUENCIA (4 a 7 pasos):
- UNA secuencia real, verificable y con UN orden lógico defendible (proceso natural, receta, cronología histórica, algoritmo).
- contexto: 1-2 frases que ambientan. instruccion: qué debe ordenar el alumno.
- pasos: texto corto por etapa (verbos en presente), orden = posición correcta (permutación exacta 1..n), pista socrática que guíe a ubicarlo SIN decir su posición.
- erroresFrecuentes: 1-4 confusiones reales de orden típicas de ese tema (para feedback docente).

META: titulo corto, aprendizajeEsperado SEP, zdpEstimada según abstracción de la secuencia.`;

const FORMAT_RULES: Record<string, string> = {
  multiple_choice: QUIZ_RULES,
  flashcards: FLASHCARDS_RULES,
  flowchart: FLOWCHART_RULES,
};

/* ---------- Esquemas Zod de salida por arquetipo ---------- */

const OUTPUT_SCHEMAS: Record<string, z.ZodTypeAny> = {
  multiple_choice: monitoContentSchema,
  flashcards: getContentSchema("flashcards"),
  flowchart: getContentSchema("flowchart"),
};

/* ---------- QA pedagógico por arquetipo ---------- */

function validateQuiz(content: MonitoContent): string[] {
  const issues: string[] = [];
  for (const [i, r] of content.reactivos.entries()) {
    const tag = `reactivo ${i + 1}`;
    const correctas = r.opciones.filter((o) => o.correcta);
    if (correctas.length !== 1)
      issues.push(`${tag}: debe tener exactamente 1 opción correcta (tiene ${correctas.length})`);
    for (const o of r.opciones) {
      if (o.correcta && o.errorCode !== null)
        issues.push(`${tag}: la correcta no debe tener errorCode`);
      if (!o.correcta && !o.errorCode)
        issues.push(`${tag}: distractor "${o.id}" sin errorCode`);
      if (!o.correcta && !o.diagnostico)
        issues.push(`${tag}: distractor "${o.id}" sin diagnostico`);
    }
    const niveles = r.andamiaje.map((s) => s.nivel).sort();
    if (niveles.join() !== "1,2,3,4,5")
      issues.push(`${tag}: el andamiaje debe tener niveles 1-5 en orden`);
    const usados = new Set(
      r.opciones
        .filter((o) => !o.correcta && o.errorCode !== null)
        .map((o) => o.errorCode!),
    );
    const cubiertos = new Set(r.feedbackPorError.map((f) => f.codigo));
    for (const code of usados)
      if (!cubiertos.has(code))
        issues.push(`${tag}: falta feedbackPorError para ${code}`);
    for (const code of ERROR_CODES)
      if (cubiertos.has(code) && !usados.has(code))
        issues.push(`${tag}: feedbackPorError sobra para ${code}`);
  }
  return issues;
}

function validateFlashcards(content: FlashcardsContent): string[] {
  const issues: string[] = [];
  if (content.tarjetas.length < 4)
    issues.push(`se requieren al menos 4 tarjetas (hay ${content.tarjetas.length})`);
  const frentes = new Set<string>();
  for (const [i, t] of content.tarjetas.entries()) {
    const key = t.frente.toLowerCase().trim();
    if (frentes.has(key)) issues.push(`tarjeta ${i + 1}: frente duplicado "${t.frente}"`);
    frentes.add(key);
    if (t.pista.toLowerCase().includes(t.reverso.toLowerCase()))
      issues.push(`tarjeta ${i + 1}: la pista revela el reverso`);
    if (t.errorTipico !== null && !ERROR_CODES.includes(t.errorTipico))
      issues.push(`tarjeta ${i + 1}: errorTipico inválido`);
  }
  return issues;
}

function validateFlowchart(content: FlowchartContent): string[] {
  const issues: string[] = [];
  const ordenes = content.pasos.map((p) => p.orden).sort((a, b) => a - b);
  const esperado = content.pasos.map((_, i) => i + 1);
  if (ordenes.join() !== esperado.join())
    issues.push(`el orden de pasos debe ser una permutación exacta de 1..${content.pasos.length} (recibido: ${ordenes.join(",")})`);
  const textos = new Set<string>();
  for (const [i, p] of content.pasos.entries()) {
    const key = p.texto.toLowerCase().trim();
    if (textos.has(key)) issues.push(`paso ${i + 1}: texto duplicado`);
    textos.add(key);
    if (/\b(primero|segundo|tercero|cuarto|quinto|paso \d|al inicio|al final)\b/i.test(p.pista))
      issues.push(`paso ${i + 1}: la pista menciona la posición`);
  }
  return issues;
}

function validateByFormat(formatId: string, content: unknown): string[] {
  if (formatId === "flashcards") return validateFlashcards(content as FlashcardsContent);
  if (formatId === "flowchart") return validateFlowchart(content as FlowchartContent);
  return validateQuiz(content as MonitoContent);
}

/* ---------- Construcción del prompt con few-shot dinámico ---------- */

function buildSystemPrompt(template: AppTemplate): string {
  const rules = FORMAT_RULES[template.formatId] ?? template.qaRules;
  return `${PEDAGOGY_CORE}

FORMATO SELECCIONADO: ${template.name} (${template.formatId})
IDONEIDAD PEDAGÓGICA DE ESTE FORMATO: ${template.pedagogicFit}

${rules}

EJEMPLO VÁLIDO DE SALIDA PARA ESTE FORMATO (few-shot — no copies su contenido, replica su estructura y rigor):
${template.exampleJson}

REGLAS DE CALIDAD QUE EL QA VERIFICARÁ:
${template.qaRules}`;
}

interface GenerateInput {
  seedQuestion: string;
  grade: number;
  subject?: string;
  learningGoal?: string;
  /** Anclaje curricular oficial (NEM/CONALITEG) si el cruce tuvo éxito */
  anchor?: CurriculumAnchor | null;
}

function buildAnchorBlock(anchor: CurriculumAnchor): string {
  const campo = CAMPO_META[anchor.campoFormativo].nombre;
  return `ANCLAJE CURRICULAR OFICIAL (Plan de Estudios 2022 · Nueva Escuela Mexicana, fase 4):
- Campo formativo: ${campo}
- Asignatura oficial: ${anchor.asignatura}
- Contenido oficial: ${anchor.contenido}
- Proceso de desarrollo de aprendizaje (PDA): ${anchor.pda}

OBLIGATORIO con este anclaje: el contenido completo debe servir a ese PDA oficial; meta.aprendizajeEsperado debe reformular el PDA en lenguaje breve y claro para el docente; meta.asignatura debe ser "${anchor.asignatura}". Los contextos y ejemplos deben ser fieles a lo que los Libros de Texto Gratuitos trabajan para este contenido.`;
}

function buildUserPrompt(input: GenerateInput, issues?: string[]): string {
  let prompt = `PREGUNTA SEMILLA DEL DOCENTE:\n"""${input.seedQuestion}"""\n\nGRADO: ${input.grade}° de primaria\nASIGNATURA: ${input.anchor ? input.anchor.asignatura : (input.subject ?? "matematicas")}`;
  if (input.learningGoal)
    prompt += `\nAPRENDIZAJE ESPERADO SUGERIDO POR EL DOCENTE: ${input.learningGoal}`;
  if (input.anchor) prompt += `\n\n${buildAnchorBlock(input.anchor)}`;
  if (issues?.length)
    prompt += `\n\nTu intento anterior violó estas reglas, corrígelas TODAS manteniendo la calidad:\n- ${issues.join("\n- ")}`;
  return prompt;
}

/* ---------- Clasificador de formato (agente adaptable) ---------- */

const classifySchema = z.object({
  formatId: z.string(),
  razon: z.string(),
});

/**
 * Dada la semilla, el agente evalúa qué plantilla del catálogo se adapta
 * mejor al objetivo pedagógico. Llamada ligera (salida mínima).
 * Si hay anclaje curricular, el campo formativo NEM sesga la elección:
 * saberes → evaluación de procedimientos; lenguajes → memorización;
 * ética/sociedades → secuencias y causas.
 */
export async function classifyFormat(
  input: GenerateInput,
  templates: AppTemplate[],
): Promise<{ formatId: string; razon: string }> {
  const catalog = templates
    .map((t) => `- ${t.formatId}: ${t.name}. Idóneo para: ${t.pedagogicFit}`)
    .join("\n");
  const anchorHint = input.anchor
    ? `\nEl anclaje curricular oficial ubica esta semilla en el campo formativo "${CAMPO_META[input.anchor.campoFormativo].nombre}" (contenido: ${input.anchor.contenido}). Guía de afinidad campo→arquetipo: Saberes y Pensamiento Científico suele pedir evaluación de procedimientos o simulación; Lenguajes y vocabulario piden memorización con repetición; Ética, Naturaleza y Sociedades con contenidos históricos o de procesos pide ordenar secuencias; De lo Humano y lo Comunitario pide reflexión aplicada. Úsala como guía, no como regla absoluta: el objetivo pedagógico de la semilla manda.`
    : "";
  try {
    const { defaultModelId } = await listModels();
    const { object } = await generateObject({
      model: kimiGw()(defaultModelId),
      schema: classifySchema,
      system: `Eres el selector de arquetipos de Monito gIA. Dada una pregunta semilla de primaria y el catálogo de formatos, eliges el que MEJOR sirve al objetivo pedagógico. Responde solo el JSON. Catálogo:\n${catalog}`,
      prompt: `Semilla: """${input.seedQuestion}""" (grado ${input.grade}°)${anchorHint}`,
      maxRetries: 0,
      providerOptions: { "kimi-gw": { max_completion_tokens: 4096 } },
    });
    // Validar que el formato elegido existe en el catálogo
    if (templates.some((t) => t.formatId === object.formatId))
      return { formatId: object.formatId, razon: object.razon };
    return { formatId: "multiple_choice", razon: "Formato por defecto" };
  } catch {
    return { formatId: "multiple_choice", razon: "Formato por defecto" };
  }
}

/* ---------- Generador principal ---------- */

export async function generateActivityFromSeed(
  input: GenerateInput,
  template: AppTemplate,
): Promise<StoredContent> {
  const schema = OUTPUT_SCHEMAS[template.formatId] ?? monitoContentSchema;
  try {
    const { defaultModelId } = await listModels();
    const model = kimiGw()(defaultModelId);
    const systemPrompt = buildSystemPrompt(template);

    let issues: string[] | undefined;
    let content: unknown = null;

    // Hasta 2 intentos: el segundo lleva las violaciones de QA como corrección
    for (let attempt = 0; attempt < 2; attempt++) {
      const { object } = await generateObject({
        model,
        schema,
        system: systemPrompt,
        prompt: buildUserPrompt(input, issues),
        maxRetries: 0,
        providerOptions: {
          "kimi-gw": { max_completion_tokens: 16384 },
        },
      });
      issues = validateByFormat(template.formatId, object);
      content = object;
      if (issues.length === 0) break;
    }

    if (!content) throw new Error("El motor no produjo contenido");
    if (issues && issues.length > 0)
      console.warn(`[MGAA:${template.formatId}] QA con observaciones:`, issues);

    return {
      schemaVersion: "monito/v2",
      formatId: template.formatId,
      runtime: { offlineFirst: true, presupuestoKb: 100 },
      ...(content as object),
    } as StoredContent;
  } catch (err) {
    throw classifyAiError(err);
  }
}
