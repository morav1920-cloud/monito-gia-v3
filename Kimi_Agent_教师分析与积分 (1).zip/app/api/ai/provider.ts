import { createOpenAICompatible } from "@ai-sdk/openai-compatible";

/**
 * Proveedor del gateway Kimi (credencial solo servidor).
 * Se construye de forma perezosa: el generador llama primero a
 * `listModels()` (que carga el .env si hace falta) antes de usarlo.
 */
let cached: ReturnType<typeof createOpenAICompatible> | null = null;

export function kimiGw() {
  if (!cached) {
    cached = createOpenAICompatible({
      name: "kimi-gw",
      baseURL: process.env.KIMI_AGENTGW_BASE_URL!,
      apiKey: process.env.KIMI_AGENTGW_API_KEY!,
      includeUsage: true,
      supportsStructuredOutputs: true,
    });
  }
  return cached;
}
