import {
  ERROR_CODES,
  ERROR_CODE_META,
  type ErrorCode,
} from "@contracts/monito";

export interface DiagnosisInput {
  sessionsCount: number;
  responsesCount: number;
  correctRate: number | null;
  errorDistribution: Record<ErrorCode, number>;
  scaffoldHistogram: number[]; // índice 0..5
  perReactivo: Record<
    string,
    { total: number; correct: number; errors: Record<ErrorCode, number> }
  >;
  /** Etiquetas cortas de reactivos para referenciar hotspots (R1, R2…) */
  reactivoOrder: string[];
}

export interface DiagnosisInsight {
  tone: "alert" | "ok" | "info";
  title: string;
  body: string;
}

/** Intervención pedagógica sugerida por código de error dominante */
const INTERVENTION: Record<
  ErrorCode,
  { foco: string; accion: string }
> = {
  CONCEPT: {
    foco: "errores conceptuales",
    accion:
      "reenseñar el concepto con material concreto (bloques, monedas, dibujos) antes de volver al algoritmo. Una mini-lección de 10 minutos con manipulativos rinde más que repetir ejercicios.",
  },
  PROC: {
    foco: "errores procedimentales",
    accion:
      "un repaso focalizado del procedimiento paso a paso: modela 2 ejemplos pensando en voz alta y pide que verifiquen con la operación inversa. La práctica en parejas con roles (ejecutor/verificador) funciona muy bien aquí.",
  },
  ATTN: {
    foco: "errores de atención",
    accion:
      "entrenar la verificación: subrayar los datos del problema, rodear la pregunta y estimar antes de calcular. Son alumnos que sí dominan el tema; necesitan frenos, no reenseñanza.",
  },
  READ: {
    foco: "errores de lectura",
    accion:
      "trabajar la lectura del enunciado: lectura en voz alta, parafrasear el problema con sus palabras y separar 'lo que sé' de 'lo que me piden'. El cálculo no es el problema; la comprensión sí.",
  },
  GUESS: {
    foco: "respuestas al azar",
    accion:
      "bajar la presión de velocidad: da más tiempo por reactivo y pide que expliquen su elección aunque sea con un dibujo. El azar suele esconder inseguridad, no falta de capacidad.",
  },
};

function pct(part: number, total: number) {
  return total > 0 ? Math.round((part / total) * 100) : 0;
}

/**
 * Motor de diagnóstico accionable: traduce la analítica cruda a
 * intervenciones pedagógicas concretas. Basado en reglas (costo cero
 * de tokens) para que el docente lo tenga siempre, sin esperar IA.
 */
export function buildDiagnosis(input: DiagnosisInput): DiagnosisInsight[] {
  const out: DiagnosisInsight[] = [];
  const {
    sessionsCount,
    responsesCount,
    correctRate,
    errorDistribution,
    scaffoldHistogram,
    perReactivo,
    reactivoOrder,
  } = input;

  if (responsesCount === 0) return out;

  // Muestra pequeña: advertencia metodológica
  if (responsesCount < 8) {
    out.push({
      tone: "info",
      title: "Muestra todavía pequeña",
      body: `Solo hay ${responsesCount} respuestas registradas (${sessionsCount} ${sessionsCount === 1 ? "sesión" : "sesiones"}). Las conclusiones son orientativas; con más alumnos el mapa diagnóstico se afina.`,
    });
  }

  const totalErrors = ERROR_CODES.reduce(
    (acc, c) => acc + errorDistribution[c],
    0,
  );

  // Errores dominantes (cualquier código con ≥25% de los errores)
  if (totalErrors > 0) {
    const ranked = [...ERROR_CODES]
      .map((code) => ({ code, n: errorDistribution[code] }))
      .filter(({ n }) => n > 0)
      .sort((a, b) => b.n - a.n);
    for (const { code, n } of ranked) {
      const share = pct(n, totalErrors);
      if (share < 25) continue;
      const meta = ERROR_CODE_META[code];
      const inter = INTERVENTION[code];
      out.push({
        tone: "alert",
        title: `El ${share}% de los errores son ${meta.nombre} (${code})`,
        body: `De ${totalErrors} errores, ${n} son de tipo ${code} (${inter.foco}). Se recomienda ${inter.accion}`,
      });
      break; // solo el dominante, para no saturar
    }
  }

  // Hotspot por reactivo
  const entries = Object.entries(perReactivo);
  if (entries.length > 1) {
    const hotspot = entries
      .map(([rid, r]) => ({
        rid,
        errors: r.total - r.correct,
        rate: r.total > 0 ? (r.total - r.correct) / r.total : 0,
      }))
      .filter((h) => h.errors > 0)
      .sort((a, b) => b.rate - a.rate || b.errors - a.errors)[0];
    if (hotspot && hotspot.rate >= 0.5 && hotspot.errors >= 2) {
      const idx = reactivoOrder.indexOf(hotspot.rid);
      const label = idx >= 0 ? `el reactivo ${idx + 1}` : "un reactivo";
      out.push({
        tone: "alert",
        title: `Punto crítico: ${label}`,
        body: `El ${pct(hotspot.errors, perReactivo[hotspot.rid].total)}% de los intentos en ${label} terminaron en error. Revísalo con el grupo completo en el pizarrón antes de seguir avanzando.`,
      });
    }
  }

  // Profundidad del andamiaje
  const total = scaffoldHistogram.reduce((a, b) => a + b, 0);
  if (total > 0) {
    const deep = scaffoldHistogram[4] + scaffoldHistogram[5];
    const noHints = scaffoldHistogram[0];
    const deepShare = pct(deep, total);
    const noHintShare = pct(noHints, total);
    if (deepShare >= 35) {
      out.push({
        tone: "info",
        title: `El ${deepShare}% necesitó los peldaños profundos`,
        body: `Muchos alumnos llegaron al peldaño 4 o 5 (descomposición y análogo resuelto). El tema está en el límite superior de su ZDP: considera un repaso previo más sencillo antes de la próxima actividad.`,
      });
    } else if (
      noHintShare >= 70 &&
      correctRate !== null &&
      correctRate >= 0.85 &&
      total >= 8
    ) {
      out.push({
        tone: "ok",
        title: "Dominio sólido del grupo",
        body: `El ${noHintShare}% resolvió sin pistas y la tasa de aciertos es ${pct(correctRate, 1)}%. Están listos para un reto mayor: sube la complejidad de los números o introduce un paso extra en el problema.`,
      });
    }
  }

  // Tasa global
  if (correctRate !== null && responsesCount >= 8) {
    if (correctRate < 0.5) {
      out.push({
        tone: "alert",
        title: `Tasa de aciertos de ${pct(correctRate, 1)}%: reenseñar`,
        body: `Menos de la mitad de las respuestas fueron correctas. Antes de más práctica independiente, vuelve a enseñar el tema con otro enfoque (visual, concreto o en equipo).`,
      });
    }
  }

  if (out.length === 0) {
    out.push({
      tone: "ok",
      title: "Sin señales críticas",
      body: `El grupo avanza de forma equilibrada: errores variados sin patrón dominante y uso moderado del andamiaje. Continúa con la secuencia planeada.`,
    });
  }

  return out;
}
