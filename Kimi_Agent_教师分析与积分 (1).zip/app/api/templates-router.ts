import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery, adminQuery } from "./middleware";
import {
  createTemplate,
  deleteTemplate,
  findTemplateByFormatId,
  listActiveTemplates,
  listAllTemplates,
  setTemplateActive,
} from "./queries/templates";
import { getContentSchema, CONTENT_SCHEMAS, type FormatId } from "@contracts/monito";

const TEMPLATE_INPUT = z.object({
  formatId: z
    .string()
    .min(3)
    .max(40)
    .regex(/^[a-z][a-z0-9_]*$/, "solo minúsculas, números y guion bajo"),
  name: z.string().min(3).max(120),
  icon: z.string().max(40).default("blocks"),
  description: z.string().min(10),
  pedagogicFit: z.string().min(10),
  exampleJson: z.string().min(20),
  qaRules: z.string().min(10),
});

export const templatesRouter = createRouter({
  /** Catálogo activo (todos los docentes) */
  list: authedQuery.query(async () => {
    const rows = await listActiveTemplates();
    return rows.map((t) => ({
      id: t.id,
      formatId: t.formatId,
      name: t.name,
      icon: t.icon,
      description: t.description,
      pedagogicFit: t.pedagogicFit,
      isBuiltin: t.isBuiltin,
      hasRuntime: ["multiple_choice", "flashcards", "flowchart"].includes(
        t.formatId,
      ),
    }));
  }),

  /** Catálogo completo con few-shot (solo admin) */
  listAll: adminQuery.query(async () => listAllTemplates()),

  /** Registra un nuevo arquetipo (solo admin). Valida el ejemplo contra el esquema si el formato es conocido. */
  create: adminQuery.input(TEMPLATE_INPUT).mutation(async ({ ctx, input }) => {
    if (await findTemplateByFormatId(input.formatId))
      throw new TRPCError({
        code: "CONFLICT",
        message: "Ya existe una plantilla con ese identificador de formato",
      });
    // Si el formato tiene esquema conocido, validar que el ejemplo lo cumpla
    try {
      const example = JSON.parse(input.exampleJson);
      if (input.formatId in CONTENT_SCHEMAS)
        getContentSchema(input.formatId as FormatId).parse(example);
    } catch {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message:
          "El ejemplo JSON no es válido o no cumple el esquema de este formato",
      });
    }
    const id = await createTemplate({
      ...input,
      isBuiltin: false,
      createdBy: ctx.user.id,
    });
    return { id };
  }),

  setActive: adminQuery
    .input(z.object({ id: z.number().int(), active: z.boolean() }))
    .mutation(async ({ input }) => {
      await setTemplateActive(input.id, input.active);
      return { ok: true };
    }),

  delete: adminQuery
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ input }) => {
      const ok = await deleteTemplate(input.id);
      if (!ok)
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Las plantillas integradas no se pueden eliminar",
        });
      return { ok: true };
    }),
});
