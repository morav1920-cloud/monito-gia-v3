import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery } from "./middleware";
import { generateActivityFromSeed, classifyFormat } from "./ai/generator";
import {
  AiMisconfigured,
  AiUnavailable,
  ContentRejected,
} from "./ai/ai-client";
import {
  createActivity,
  deleteActivity,
  findActivityById,
  listActivitiesByTeacher,
  setActivityStatus,
} from "./queries/activities";
import { findLibraryMatches } from "./queries/library";
import { matchCurriculum } from "./queries/curriculum";
import {
  findTemplateByFormatId,
  listActiveTemplates,
} from "./queries/templates";
import {
  assertCanAfford,
  chargeCredits,
  InsufficientCreditsError,
} from "./queries/credits";
import { CREDIT_COSTS } from "@contracts/credits";

function mapAiError(err: unknown): never {
  // Degradación elegante: códigos que el frontend traduce a español
  if (err instanceof AiUnavailable)
    throw new TRPCError({ code: "FORBIDDEN", message: "AI_QUOTA" });
  if (err instanceof ContentRejected)
    throw new TRPCError({ code: "BAD_REQUEST", message: "AI_CONTENT" });
  if (err instanceof AiMisconfigured)
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "AI_CONFIG",
    });
  throw new TRPCError({
    code: "INTERNAL_SERVER_ERROR",
    message: "AI_TRANSIENT",
  });
}

export const activitiesRouter = createRouter({
  /**
   * Genera una actividad MonitoSchema v2 desde la pregunta semilla.
   * Flujo ultra-rentable: antes de gastar tokens busca en la biblioteca
   * comunitaria; si hay coincidencia fuerte, la devuelve sin cobrar.
   */
  generate: authedQuery
    .input(
      z.object({
        seedQuestion: z.string().min(10).max(2000),
        grade: z.number().int().min(3).max(6),
        learningGoal: z.string().max(500).optional(),
        /** "variant": variante isomorfa a partir de una actividad de la biblioteca */
        mode: z.enum(["original", "variant"]).default("original"),
        /** Requerido si mode=variant */
        sourceActivityId: z.number().int().optional(),
        /** true = el docente ya vio los matches y quiere generar igual */
        skipLibraryCheck: z.boolean().default(false),
        /** Arquetipo forzado por el docente; si no viene, el agente clasifica */
        formatId: z.string().max(40).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const cost =
        input.mode === "variant" ? CREDIT_COSTS.variant : CREDIT_COSTS.generation;

      // 1. Biblioteca primero: cero tokens si la comunidad ya lo resolvió
      if (!input.skipLibraryCheck && input.mode === "original") {
        const { strong } = await findLibraryMatches(
          input.seedQuestion,
          input.grade,
          ctx.user.id,
        );
        if (strong.length > 0) {
          return {
            kind: "library_matches" as const,
            matches: strong,
            costs: CREDIT_COSTS,
          };
        }
      }

      // 2. Validar saldo ANTES de llamar a la IA
      try {
        await assertCanAfford(ctx.user.id, cost);
      } catch (err) {
        if (err instanceof InsufficientCreditsError)
          throw new TRPCError({
            code: "PRECONDITION_FAILED",
            message: "NO_CREDITS",
          });
        throw err;
      }

      // 3. Anclaje curricular: cruce semántico-léxico con el índice NEM/CONALITEG.
      // (cero tokens — es cómputo local sobre la base de conocimiento)
      //    En variante, hereda el anclaje de la actividad fuente si existe.
      let anchor = null;
      if (input.mode === "variant" && input.sourceActivityId) {
        const sourceForAnchor = await findActivityById(input.sourceActivityId);
        anchor = sourceForAnchor?.curriculumAnchor ?? null;
      }
      if (!anchor) {
        anchor = await matchCurriculum(
          `${input.seedQuestion} ${input.learningGoal ?? ""}`,
          input.grade,
        );
      }

      // 4. Selección de arquetipo: override del docente o clasificador IA
      //    (el clasificador recibe el campo formativo como sesgo de afinidad)
      const activeTemplates = await listActiveTemplates();
      let template;
      let clasificacion: { razon: string; automatico: boolean } | null = null;
      if (input.formatId) {
        template = activeTemplates.find((t) => t.formatId === input.formatId);
        if (!template)
          throw new TRPCError({ code: "BAD_REQUEST", message: "UNKNOWN_FORMAT" });
      } else {
        const pick = await classifyFormat(
          {
            seedQuestion: input.seedQuestion,
            grade: input.grade,
            learningGoal: input.learningGoal,
            anchor,
          },
          activeTemplates,
        );
        template =
          activeTemplates.find((t) => t.formatId === pick.formatId) ??
          (await findTemplateByFormatId("multiple_choice"))!;
        clasificacion = { razon: pick.razon, automatico: true };
      }

      // 5. Variante: el contexto de la semilla base enriquece el prompt
      let seed = input.seedQuestion;
      let grade = input.grade;
      let goal = input.learningGoal;
      if (input.mode === "variant" && input.sourceActivityId) {
        const source = await findActivityById(input.sourceActivityId);
        if (source && source.isSharedToLibrary) {
          seed = `${input.seedQuestion}\n\n(Referencia de actividad ya validada: "${source.seedQuestion}". Genera una VARIANTE ISOMORFA: mismo aprendizaje, contextos y números completamente nuevos.)`;
          grade = source.grade;
          goal = goal ?? source.learningGoal ?? undefined;
          if (!input.formatId) {
            // la variante hereda el arquetipo de la fuente
            const sourceTemplate = activeTemplates.find(
              (t) => t.formatId === source.formatId,
            );
            if (sourceTemplate) {
              template = sourceTemplate;
              clasificacion = null;
            }
          }
        }
      }

      // 6. Generación con IA (few-shot dinámico de la plantilla + anclaje oficial)
      let content;
      try {
        content = await generateActivityFromSeed(
          { seedQuestion: seed, grade, learningGoal: goal, anchor },
          template,
        );
      } catch (err) {
        mapAiError(err);
      }

      // 7. Persistir y cobrar (solo si la generación tuvo éxito)
      const insertId = await createActivity({
        teacherId: ctx.user.id,
        title: content.meta.titulo,
        subject: anchor?.asignatura ?? content.meta.asignatura,
        grade, // en variante hereda el grado de la actividad fuente
        seedQuestion: input.seedQuestion,
        learningGoal: input.learningGoal ?? content.meta.aprendizajeEsperado,
        status: "draft",
        origin: "ai",
        formatId: template.formatId,
        curriculumAnchor: anchor ?? undefined,
        clonedFromId: input.mode === "variant" ? input.sourceActivityId : undefined,
        content,
      });
      const newBalance = await chargeCredits(
        ctx.user.id,
        cost,
        input.mode === "variant" ? "variant" : "generation",
        insertId,
      );
      const activity = await findActivityById(insertId);
      if (!activity) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      return {
        kind: "activity" as const,
        activity,
        newBalance,
        charged: cost,
        clasificacion,
        anclaje: anchor,
      };
    }),

  list: authedQuery.query(async ({ ctx }) => {
    const rows = await listActivitiesByTeacher(ctx.user.id);
    // Lista sin el contenido completo (payload ligero)
    return rows.map(({ content, ...rest }) => ({
      ...rest,
      reactivosCount:
        content.reactivos?.length ??
        content.tarjetas?.length ??
        content.pasos?.length ??
        0,
      zdpEstimada: content.meta.zdpEstimada,
    }));
  }),

  byId: authedQuery
    .input(z.object({ id: z.number().int() }))
    .query(async ({ ctx, input }) => {
      const activity = await findActivityById(input.id);
      if (!activity || activity.teacherId !== ctx.user.id)
        throw new TRPCError({ code: "NOT_FOUND" });
      return activity;
    }),

  setStatus: authedQuery
    .input(
      z.object({
        id: z.number().int(),
        status: z.enum(["draft", "published"]),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      await setActivityStatus(input.id, ctx.user.id, input.status);
      return { ok: true };
    }),

  delete: authedQuery
    .input(z.object({ id: z.number().int() }))
    .mutation(async ({ ctx, input }) => {
      const ok = await deleteActivity(input.id, ctx.user.id);
      if (!ok) throw new TRPCError({ code: "NOT_FOUND" });
      return { ok: true };
    }),
});
