import { desc, eq, inArray } from "drizzle-orm";
import * as schema from "@db/schema";
import type { InsertResponse } from "@db/schema";
import { getDb } from "./connection";

export async function createPlaySession(activityId: number, alias: string) {
  const [result] = await getDb()
    .insert(schema.playSessions)
    .values({ activityId, studentAlias: alias });
  return result.insertId;
}

export async function findSessionById(id: number) {
  const rows = await getDb()
    .select()
    .from(schema.playSessions)
    .where(eq(schema.playSessions.id, id))
    .limit(1);
  return rows.at(0);
}

export async function insertResponse(data: InsertResponse) {
  await getDb().insert(schema.responses).values(data);
}

export async function finishPlaySession(
  id: number,
  stats: { correctCount: number; totalAnswered: number; maxScaffoldUsed: number },
) {
  await getDb()
    .update(schema.playSessions)
    .set({ ...stats, finishedAt: new Date() })
    .where(eq(schema.playSessions.id, id));
}

/** Respuestas de una actividad (join con sesiones) */
export async function findResponsesByActivity(activityId: number) {
  const sessions = await getDb()
    .select()
    .from(schema.playSessions)
    .where(eq(schema.playSessions.activityId, activityId))
    .orderBy(desc(schema.playSessions.createdAt));
  if (sessions.length === 0) return { sessions: [], responses: [] };
  const rows = await getDb()
    .select()
    .from(schema.responses)
    .where(
      inArray(
        schema.responses.sessionId,
        sessions.map((s) => s.id),
      ),
    );
  return { sessions, responses: rows };
}
