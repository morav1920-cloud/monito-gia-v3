import * as schema from "@db/schema";
import { getDb } from "./connection";
import { tokenizeSeed } from "./library";
import type { CurriculumAnchor } from "@contracts/curriculum";

/**
 * Cruce semántico-léxico entre la semilla docente y el índice curricular
 * oficial. Reutiliza el tokenizador probado de la biblioteca: Jaccard sobre
 * tokens significativos, con peso extra para el contenido y las keywords.
 */

// Umbral mínimo para anclar (evita anclajes espurios con temas ajenos)
const ANCHOR_THRESHOLD = 0.22;
// Exige al menos 2 coincidencias fuertes (keywords/contenido) para anclar;
// un solo término compartido ("juegos", "agua") no basta para certificar
const MIN_STRONG_HITS = 2;

/** Jaccard ponderado: keywords y contenido pesan doble que el PDA */
function anchorScore(
  seedTokens: Set<string>,
  entry: schema.CurriculumEntry,
): { score: number; strongHits: number } {
  const fuerte = tokenizeSeed(`${entry.contenido} ${entry.keywords}`);
  const suave = tokenizeSeed(entry.pda);
  let hitsFuerte = 0;
  let hitsSuave = 0;
  for (const t of seedTokens) {
    if (fuerte.has(t)) hitsFuerte += 1;
    else if (suave.has(t)) hitsSuave += 1;
  }
  const hits = hitsFuerte * 2 + hitsSuave;
  if (hits === 0) return { score: 0, strongHits: 0 };
  // Cobertura sobre la semilla, normalizada por el tamaño del vocabulario
  // de la entrada (entradas con índice más específico no se penalizan)
  const coverage = hits / seedTokens.size;
  const focus = Math.min(1, Math.sqrt(seedTokens.size / (fuerte.size + 4)));
  return { score: coverage * focus, strongHits: hitsFuerte };
}

/**
 * Ancla una semilla al currículo oficial para el grado indicado.
 * Considera el grado exacto y, con penalización, los grados vecinos
 * (el docente puede sembrar un repaso del año anterior).
 */
export async function matchCurriculum(
  seedQuestion: string,
  grade: number,
): Promise<CurriculumAnchor | null> {
  const db = getDb();
  const rows = await db.select().from(schema.curriculumEntries);
  const seedTokens = tokenizeSeed(seedQuestion);
  if (seedTokens.size === 0) return null;

  let best: { entry: schema.CurriculumEntry; score: number } | null = null;
  for (const entry of rows) {
    const { score: rawScore, strongHits } = anchorScore(seedTokens, entry);
    if (rawScore === 0) continue;
    if (Math.abs(entry.grade - grade) > 1) continue; // demasiado lejos
    // Sin evidencia suficiente, no certificamos anclaje
    if (strongHits < MIN_STRONG_HITS && rawScore < 0.4) continue;
    let score = rawScore;
    if (entry.grade === grade) score += 0.08; // mismo grado: prioridad
    if (!best || score > best.score) best = { entry, score };
  }

  if (!best || best.score < ANCHOR_THRESHOLD) return null;
  return {
    campoFormativo: best.entry.campoFormativo,
    asignatura: best.entry.asignatura,
    contenido: best.entry.contenido,
    pda: best.entry.pda,
    score: Math.round(best.score * 100) / 100,
  };
}

/** Catálogo curricular (exploración por campo/grado — útil para admin) */
export async function listCurriculum(opts?: {
  campoFormativo?: string;
  grade?: number;
}) {
  const db = getDb();
  const rows = await db.select().from(schema.curriculumEntries);
  return rows.filter(
    (r) =>
      (!opts?.campoFormativo || r.campoFormativo === opts.campoFormativo) &&
      (!opts?.grade || r.grade === opts.grade),
  );
}
