import { and, desc, eq } from "drizzle-orm";
import * as schema from "@db/schema";
import type { InsertActivity } from "@db/schema";
import { getDb } from "./connection";

const CODE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

export function generateShareCode(): string {
  let code = "";
  for (let i = 0; i < 4; i++)
    code += CODE_ALPHABET[Math.floor(Math.random() * CODE_ALPHABET.length)];
  return `MON-${code}`;
}

export async function createActivity(
  data: Omit<InsertActivity, "shareCode">,
) {
  // Reintenta si el código corto colisiona (unique)
  for (let i = 0; i < 5; i++) {
    try {
      const [result] = await getDb()
        .insert(schema.activities)
        .values({ ...data, shareCode: generateShareCode() });
      return result.insertId;
    } catch (err) {
      if (i === 4) throw err;
    }
  }
  throw new Error("No se pudo asignar código de actividad");
}

export async function listActivitiesByTeacher(teacherId: number) {
  return getDb()
    .select()
    .from(schema.activities)
    .where(eq(schema.activities.teacherId, teacherId))
    .orderBy(desc(schema.activities.createdAt));
}

export async function findActivityById(id: number) {
  const rows = await getDb()
    .select()
    .from(schema.activities)
    .where(eq(schema.activities.id, id))
    .limit(1);
  return rows.at(0);
}

export async function findPublishedActivityByCode(shareCode: string) {
  const rows = await getDb()
    .select()
    .from(schema.activities)
    .where(
      and(
        eq(schema.activities.shareCode, shareCode.toUpperCase()),
        eq(schema.activities.status, "published"),
      ),
    )
    .limit(1);
  return rows.at(0);
}

export async function setActivityStatus(
  id: number,
  teacherId: number,
  status: "draft" | "published",
) {
  await getDb()
    .update(schema.activities)
    .set({ status })
    .where(
      and(
        eq(schema.activities.id, id),
        eq(schema.activities.teacherId, teacherId),
      ),
    );
}

export async function deleteActivity(id: number, teacherId: number) {
  const activity = await findActivityById(id);
  if (!activity || activity.teacherId !== teacherId) return false;
  const sessions = await getDb()
    .select({ id: schema.playSessions.id })
    .from(schema.playSessions)
    .where(eq(schema.playSessions.activityId, id));
  for (const s of sessions)
    await getDb()
      .delete(schema.responses)
      .where(eq(schema.responses.sessionId, s.id));
  await getDb()
    .delete(schema.playSessions)
    .where(eq(schema.playSessions.activityId, id));
  await getDb()
    .delete(schema.activities)
    .where(eq(schema.activities.id, id));
  return true;
}
