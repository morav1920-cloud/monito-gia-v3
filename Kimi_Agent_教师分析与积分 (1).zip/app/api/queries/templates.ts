import { asc, eq } from "drizzle-orm";
import * as schema from "@db/schema";
import type { InsertAppTemplate } from "@db/schema";
import { getDb } from "./connection";

export async function listActiveTemplates() {
  return getDb()
    .select()
    .from(schema.appTemplates)
    .where(eq(schema.appTemplates.isActive, true))
    .orderBy(asc(schema.appTemplates.id));
}

export async function listAllTemplates() {
  return getDb()
    .select()
    .from(schema.appTemplates)
    .orderBy(asc(schema.appTemplates.id));
}

export async function findTemplateByFormatId(formatId: string) {
  const rows = await getDb()
    .select()
    .from(schema.appTemplates)
    .where(eq(schema.appTemplates.formatId, formatId))
    .limit(1);
  return rows.at(0);
}

export async function createTemplate(data: InsertAppTemplate) {
  const [result] = await getDb().insert(schema.appTemplates).values(data);
  return result.insertId;
}

export async function setTemplateActive(id: number, active: boolean) {
  await getDb()
    .update(schema.appTemplates)
    .set({ isActive: active })
    .where(eq(schema.appTemplates.id, id));
}

export async function deleteTemplate(id: number) {
  const row = await getDb()
    .select()
    .from(schema.appTemplates)
    .where(eq(schema.appTemplates.id, id))
    .limit(1);
  const t = row.at(0);
  if (!t || t.isBuiltin) return false;
  await getDb().delete(schema.appTemplates).where(eq(schema.appTemplates.id, id));
  return true;
}
