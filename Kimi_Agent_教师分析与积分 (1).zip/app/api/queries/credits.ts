import { desc, eq } from "drizzle-orm";
import * as schema from "@db/schema";
import type { CreditReason } from "@contracts/credits";
import { WELCOME_CREDITS } from "@contracts/credits";
import { getDb } from "./connection";

export class InsufficientCreditsError extends Error {
  readonly balance: number;
  constructor(balance: number) {
    super("NO_CREDITS");
    this.name = "InsufficientCreditsError";
    this.balance = balance;
  }
}

/**
 * Devuelve el monedero del docente. Si no existe, lo crea
 * y abona el bono de bienvenida en una sola operación.
 */
export async function getOrCreateWallet(userId: number) {
  const db = getDb();
  const existing = await db
    .select()
    .from(schema.creditWallets)
    .where(eq(schema.creditWallets.userId, userId))
    .limit(1);
  if (existing.at(0)) return existing[0];

  await db.insert(schema.creditWallets).values({ userId, balance: WELCOME_CREDITS });
  await db.insert(schema.creditTransactions).values({
    userId,
    amount: WELCOME_CREDITS,
    reason: "welcome",
    balanceAfter: WELCOME_CREDITS,
  });
  const created = await db
    .select()
    .from(schema.creditWallets)
    .where(eq(schema.creditWallets.userId, userId))
    .limit(1);
  return created[0];
}

/**
 * Carga créditos tras una operación exitosa. Valida saldo ANTES
 * de llamar a la IA (el router lo hace); aquí solo se registra.
 */
export async function chargeCredits(
  userId: number,
  amount: number,
  reason: CreditReason,
  activityId?: number,
) {
  const wallet = await getOrCreateWallet(userId);
  const newBalance = wallet.balance - amount;
  if (newBalance < 0) throw new InsufficientCreditsError(wallet.balance);
  const db = getDb();
  await db
    .update(schema.creditWallets)
    .set({ balance: newBalance })
    .where(eq(schema.creditWallets.userId, userId));
  await db.insert(schema.creditTransactions).values({
    userId,
    amount: -amount,
    reason,
    activityId,
    balanceAfter: newBalance,
  });
  return newBalance;
}

/** Valida que el docente pueda pagar `amount` sin cobrar todavía */
export async function assertCanAfford(userId: number, amount: number) {
  const wallet = await getOrCreateWallet(userId);
  if (wallet.balance < amount) throw new InsufficientCreditsError(wallet.balance);
  return wallet.balance;
}

export async function listTransactions(userId: number, limit = 30) {
  return getDb()
    .select()
    .from(schema.creditTransactions)
    .where(eq(schema.creditTransactions.userId, userId))
    .orderBy(desc(schema.creditTransactions.createdAt))
    .limit(limit);
}
