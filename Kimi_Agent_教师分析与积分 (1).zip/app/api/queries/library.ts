import { and, desc, eq, ne, sql } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./connection";
import { generateShareCode } from "./activities";
import { countReactivos } from "@contracts/monito";

/** Palabras vacías del español escolar (no aportan al emparejamiento) */
const STOPWORDS = new Set([
  "para", "como", "pero", "porque", "entonces", "cuando", "donde", "sobre",
  "entre", "hasta", "desde", "cuanto", "cuantos", "cuantas", "cuanta",
  "tiene", "tienen", "tenia", "habia", "cada", "unos", "unas", "este",
  "esta", "estos", "estas", "hay", "son", "del", "las", "los", "una",
  "con", "que", "por", "sus", "les", "mas", "menos",
]);

/** Normaliza una semilla a su conjunto de tokens significativos */
export function tokenizeSeed(text: string): Set<string> {
  const normalized = text
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase();
  const tokens = normalized
    .split(/[^a-z0-9]+/)
    .filter((t) => t.length >= 4 && !STOPWORDS.has(t))
    .map((t) => {
      // Normalización de plurales: "tablas"→"tabla", "elotes"→"elote"
      if (t.length > 5 && t.endsWith("es")) return t.slice(0, -2);
      if (t.length > 4 && t.endsWith("s") && !t.endsWith("ss")) return t.slice(0, -1);
      return t;
    });
  return new Set(tokens);
}

/** Similitud Jaccard entre dos conjuntos de tokens (0 a 1) */
export function seedSimilarity(a: string, b: string): number {
  const ta = tokenizeSeed(a);
  const tb = tokenizeSeed(b);
  if (ta.size === 0 || tb.size === 0) return 0;
  let inter = 0;
  for (const t of ta) if (tb.has(t)) inter++;
  return inter / (ta.size + tb.size - inter);
}

export interface LibraryMatch {
  id: number;
  title: string;
  grade: number;
  subject: string;
  seedQuestion: string;
  learningGoal: string | null;
  libraryClones: number;
  formatId: string;
  reactivosCount: number;
  zdpEstimada: string;
  score: number;
}

const STRONG_MATCH = 0.34;
const CANDIDATE_MATCH = 0.14;

function toMatch(a: schema.Activity, score: number): LibraryMatch {
  return {
    id: a.id,
    title: a.title,
    grade: a.grade,
    subject: a.subject,
    seedQuestion: a.seedQuestion,
    learningGoal: a.learningGoal,
    libraryClones: a.libraryClones,
    formatId: a.formatId,
    reactivosCount: countReactivos(a.content),
    zdpEstimada: a.content.meta.zdpEstimada,
    score: Math.round(score * 100) / 100,
  };
}

/**
 * Busca en la biblioteca comunitaria actividades parecidas a la semilla.
 * Devuelve { strong, candidates } — strong = prácticamente la misma
 * pregunta (entrega instantánea, costo cero); candidates = tema afín.
 */
export async function findLibraryMatches(
  seedQuestion: string,
  grade: number,
  excludeTeacherId?: number,
) {
  const shared = await listSharedActivities({ excludeTeacherId });
  const scored = shared
    .map((a) => {
      let score = seedSimilarity(seedQuestion, a.seedQuestion);
      if (a.grade === grade) score += 0.08; // mismo grado: contexto afín
      return { activity: a, score };
    })
    .filter(({ score }) => score >= CANDIDATE_MATCH)
    .sort((x, y) => y.score - x.score)
    .slice(0, 4);
  return {
    strong: scored
      .filter(({ score }) => score >= STRONG_MATCH)
      .map(({ activity, score }) => toMatch(activity, score)),
    candidates: scored
      .filter(({ score }) => score < STRONG_MATCH)
      .map(({ activity, score }) => toMatch(activity, score)),
  };
}

/** Exploración general de la biblioteca comunitaria */
export async function listSharedActivities(opts: {
  grade?: number;
  q?: string;
  excludeTeacherId?: number;
  limit?: number;
}) {
  const conditions = [eq(schema.activities.isSharedToLibrary, true)];
  if (opts.grade) conditions.push(eq(schema.activities.grade, opts.grade));
  if (opts.excludeTeacherId)
    conditions.push(ne(schema.activities.teacherId, opts.excludeTeacherId));
  const rows = await getDb()
    .select()
    .from(schema.activities)
    .where(and(...conditions))
    .orderBy(desc(schema.activities.libraryClones), desc(schema.activities.createdAt))
    .limit(opts.limit ?? 60);
  const q = opts.q?.trim();
  const filtered = q
    ? rows.filter((a) => {
        const hay =
          `${a.title} ${a.seedQuestion} ${a.learningGoal ?? ""}`.toLowerCase();
        return q
          .toLowerCase()
          .split(/\s+/)
          .every((w) => hay.includes(w));
      })
    : rows;
  return filtered;
}

/**
 * Clona una actividad compartida al estudio del docente.
 * Costo cero de tokens: el contenido MonitoSchema v2 viaja intacto.
 */
export async function cloneActivity(sourceId: number, teacherId: number) {
  const rows = await getDb()
    .select()
    .from(schema.activities)
    .where(eq(schema.activities.id, sourceId))
    .limit(1);
  const source = rows.at(0);
  if (!source || !source.isSharedToLibrary) return null;
  if (source.teacherId === teacherId) return null; // ya es tuya

  const db = getDb();
  let insertId = 0;
  for (let i = 0; i < 5; i++) {
    try {
      const [result] = await db.insert(schema.activities).values({
        teacherId,
        title: source.title,
        subject: source.subject,
        grade: source.grade,
        seedQuestion: source.seedQuestion,
        learningGoal: source.learningGoal,
        status: "draft",
        shareCode: generateShareCode(),
        origin: "clone",
        clonedFromId: source.id,
        curriculumAnchor: source.curriculumAnchor,
        content: source.content,
      });
      insertId = result.insertId;
      break;
    } catch {
      if (i === 4) throw new Error("No se pudo asignar código");
    }
  }
  await db
    .update(schema.activities)
    .set({ libraryClones: sql`${schema.activities.libraryClones} + 1` })
    .where(eq(schema.activities.id, source.id));
  return insertId;
}

/** Marca/desmarca una actividad propia como compartida (debe estar publicada) */
export async function setLibraryShared(
  id: number,
  teacherId: number,
  shared: boolean,
) {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.activities)
    .where(
      and(
        eq(schema.activities.id, id),
        eq(schema.activities.teacherId, teacherId),
      ),
    )
    .limit(1);
  const activity = rows.at(0);
  if (!activity) return { ok: false as const, reason: "not_found" };
  if (shared && activity.status !== "published")
    return { ok: false as const, reason: "not_published" };
  await db
    .update(schema.activities)
    .set({ isSharedToLibrary: shared })
    .where(eq(schema.activities.id, id));
  return { ok: true as const };
}
