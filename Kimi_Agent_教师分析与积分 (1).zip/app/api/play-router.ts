import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { errorCodeSchema } from "@contracts/monito";
import { createRouter, publicQuery } from "./middleware";
import { findPublishedActivityByCode } from "./queries/activities";
import {
  createPlaySession,
  findSessionById,
  finishPlaySession,
  insertResponse,
} from "./queries/play";

export const playRouter = createRouter({
  /** Actividad publicada para el alumno (sin diagnósticos docentes) */
  byCode: publicQuery
    .input(z.object({ code: z.string().min(4).max(12) }))
    .query(async ({ input }) => {
      const activity = await findPublishedActivityByCode(input.code);
      if (!activity)
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Código no encontrado o actividad no publicada",
        });
      const c = activity.content;
      // Sanitización por arquetipo: nunca filtrar respuestas ni diagnósticos
      let content: unknown = c;
      if (c.formatId === "flashcards" && c.tarjetas) {
        // En flashcards el reverso ES el contenido de aprendizaje (se revela
        // al voltear): no se sanitiza. Solo se omite la etiqueta docente.
        content = {
          ...c,
          tarjetas: c.tarjetas.map(({ errorTipico, ...t }) => t),
        };
      } else if (c.formatId === "flowchart" && c.pasos) {
        // El orden correcto viaja como mapa interno (misma arquitectura que
        // opciones.correcta del quiz: la autoevaluación es client-side)
        const orden: Record<string, number> = {};
        for (const p of c.pasos) orden[p.id] = p.orden;
        content = {
          ...c,
          pasos: c.pasos.map(({ orden: _orden, ...p }) => p),
          _orden: orden,
        };
      } else if (c.reactivos) {
        content = {
          ...c,
          reactivos: c.reactivos.map((r) => ({
            ...r,
            opciones: r.opciones.map(({ diagnostico, ...o }) => o),
          })),
        };
      }
      return {
        id: activity.id,
        title: activity.title,
        shareCode: activity.shareCode,
        formatId: c.formatId ?? "multiple_choice",
        campoFormativo: activity.curriculumAnchor?.campoFormativo ?? null,
        contenidoOficial: activity.curriculumAnchor?.contenido ?? null,
        content,
      };
    }),

  startSession: publicQuery
    .input(
      z.object({
        code: z.string().min(4).max(12),
        alias: z.string().min(1).max(60),
      }),
    )
    .mutation(async ({ input }) => {
      const activity = await findPublishedActivityByCode(input.code);
      if (!activity)
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Código no encontrado o actividad no publicada",
        });
      const sessionId = await createPlaySession(activity.id, input.alias);
      return { sessionId };
    }),

  submitResponse: publicQuery
    .input(
      z.object({
        sessionId: z.number().int(),
        reactivoId: z.string().max(60),
        // En quiz es la opción elegida; en flashcards/flowchart es el id del paso/tarjeta o "-"
        selectedOptionId: z.string().max(64).default("-"),
        isCorrect: z.boolean(),
        errorCode: errorCodeSchema.nullable(),
        scaffoldLevel: z.number().int().min(0).max(5),
        timeMs: z.number().int().min(0).max(3_600_000),
      }),
    )
    .mutation(async ({ input }) => {
      const session = await findSessionById(input.sessionId);
      if (!session) throw new TRPCError({ code: "NOT_FOUND" });
      await insertResponse({
        sessionId: input.sessionId,
        reactivoId: input.reactivoId,
        selectedOptionId: input.selectedOptionId,
        isCorrect: input.isCorrect,
        errorCode: input.isCorrect ? null : input.errorCode,
        scaffoldLevel: input.scaffoldLevel,
        timeMs: input.timeMs,
      });
      return { ok: true };
    }),

  finishSession: publicQuery
    .input(
      z.object({
        sessionId: z.number().int(),
        correctCount: z.number().int().min(0),
        totalAnswered: z.number().int().min(0),
        maxScaffoldUsed: z.number().int().min(0).max(5),
      }),
    )
    .mutation(async ({ input }) => {
      const session = await findSessionById(input.sessionId);
      if (!session) throw new TRPCError({ code: "NOT_FOUND" });
      await finishPlaySession(input.sessionId, {
        correctCount: input.correctCount,
        totalAnswered: input.totalAnswered,
        maxScaffoldUsed: input.maxScaffoldUsed,
      });
      return { ok: true };
    }),
});
