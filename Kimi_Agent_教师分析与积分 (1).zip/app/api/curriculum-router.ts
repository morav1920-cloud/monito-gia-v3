import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { listCurriculum, matchCurriculum } from "./queries/curriculum";
import { CAMPOS_FORMATIVOS } from "@contracts/curriculum";

/** Base de conocimiento curricular NEM/CONALITEG (fase 4: 3°-6°) */
export const curriculumRouter = createRouter({
  /** Explora el índice oficial por campo formativo y/o grado */
  browse: authedQuery
    .input(
      z.object({
        campoFormativo: z.enum(CAMPOS_FORMATIVOS).optional(),
        grade: z.number().int().min(3).max(6).optional(),
      }),
    )
    .query(async ({ input }) => listCurriculum(input)),

  /**
   * Vista previa del anclaje: cruza una semilla con el índice oficial
   * SIN generar nada ni cobrar créditos (cómputo local, cero tokens).
   */
  anchorPreview: authedQuery
    .input(
      z.object({
        seedQuestion: z.string().min(10).max(2000),
        grade: z.number().int().min(3).max(6),
      }),
    )
    .mutation(async ({ input }) => {
      const anchor = await matchCurriculum(input.seedQuestion, input.grade);
      return { anchor };
    }),
});
