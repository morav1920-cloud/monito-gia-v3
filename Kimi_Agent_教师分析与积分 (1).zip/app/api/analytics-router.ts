import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { ERROR_CODES, type ErrorCode } from "@contracts/monito";
import { createRouter, authedQuery } from "./middleware";
import {
  findActivityById,
  listActivitiesByTeacher,
} from "./queries/activities";
import { findResponsesByActivity } from "./queries/play";
import { buildDiagnosis } from "./diagnosis";

type ErrorDist = Record<ErrorCode, number>;

function emptyDist(): ErrorDist {
  return { CONCEPT: 0, PROC: 0, ATTN: 0, READ: 0, GUESS: 0 };
}

export const analyticsRouter = createRouter({
  /** Totales del docente para el panel principal + diagnóstico grupal */
  overview: authedQuery.query(async ({ ctx }) => {
    const activities = await listActivitiesByTeacher(ctx.user.id);
    let sessionsCount = 0;
    let responsesCount = 0;
    let correctCount = 0;
    const errorTotals: ErrorDist = emptyDist();
    const scaffoldTotals = [0, 0, 0, 0, 0, 0];
    /** Mapa de calor grupal: actividad × taxonomía */
    const heatRows: {
      activityId: number;
      title: string;
      grade: number;
      cells: ErrorDist;
      total: number;
    }[] = [];

    for (const a of activities) {
      const { sessions, responses } = await findResponsesByActivity(a.id);
      sessionsCount += sessions.length;
      responsesCount += responses.length;
      const cells = emptyDist();
      for (const r of responses) {
        scaffoldTotals[Math.min(r.scaffoldLevel, 5)]++;
        if (r.isCorrect) correctCount++;
        else if (r.errorCode && ERROR_CODES.includes(r.errorCode as ErrorCode)) {
          errorTotals[r.errorCode as ErrorCode]++;
          cells[r.errorCode as ErrorCode]++;
        }
      }
      if (sessions.length > 0)
        heatRows.push({
          activityId: a.id,
          title: a.title,
          grade: a.grade,
          cells,
          total: responses.length,
        });
    }
    const dominantError =
      (Object.entries(errorTotals).sort((a, b) => b[1] - a[1])[0] as
        | [ErrorCode, number]
        | undefined) ?? null;

    // Diagnóstico grupal: mismas reglas, agregado de todas las actividades
    const diagnosis = buildDiagnosis({
      sessionsCount,
      responsesCount,
      correctRate: responsesCount > 0 ? correctCount / responsesCount : null,
      errorDistribution: errorTotals,
      scaffoldHistogram: scaffoldTotals,
      perReactivo: {},
      reactivoOrder: [],
    });

    return {
      activitiesCount: activities.length,
      publishedCount: activities.filter((a) => a.status === "published").length,
      sessionsCount,
      responsesCount,
      correctRate: responsesCount > 0 ? correctCount / responsesCount : null,
      dominantError:
        dominantError && dominantError[1] > 0 ? dominantError[0] : null,
      errorTotals,
      scaffoldTotals,
      heatRows,
      diagnosis,
    };
  }),

  /** Analítica diagnóstica de una actividad (solo el docente dueño) */
  activityStats: authedQuery
    .input(z.object({ activityId: z.number().int() }))
    .query(async ({ ctx, input }) => {
      const activity = await findActivityById(input.activityId);
      if (!activity || activity.teacherId !== ctx.user.id)
        throw new TRPCError({ code: "NOT_FOUND" });

      const { sessions, responses } = await findResponsesByActivity(
        input.activityId,
      );

      const errorDistribution: ErrorDist = emptyDist();
      const scaffoldHistogram = [0, 0, 0, 0, 0, 0]; // índice = peldaño usado
      const perReactivo: Record<
        string,
        { total: number; correct: number; errors: ErrorDist }
      > = {};
      // Orden de filas del mapa de calor según el arquetipo:
      // quiz → ids de reactivos; flashcards → ids de tarjetas; flowchart → la secuencia completa
      const reactivoOrder: string[] =
        activity.content.reactivos?.map((r) => r.id) ??
        activity.content.tarjetas?.map((t) => t.id) ??
        (activity.content.pasos ? ["secuencia"] : []);

      for (const r of responses) {
        scaffoldHistogram[Math.min(r.scaffoldLevel, 5)]++;
        if (!perReactivo[r.reactivoId])
          perReactivo[r.reactivoId] = {
            total: 0,
            correct: 0,
            errors: emptyDist(),
          };
        const bucket = perReactivo[r.reactivoId];
        bucket.total++;
        if (r.isCorrect) bucket.correct++;
        else if (r.errorCode && r.errorCode in errorDistribution) {
          errorDistribution[r.errorCode as ErrorCode]++;
          bucket.errors[r.errorCode as ErrorCode]++;
        }
      }

      const correctRate =
        responses.length > 0
          ? responses.filter((r) => r.isCorrect).length / responses.length
          : null;

      const diagnosis = buildDiagnosis({
        sessionsCount: sessions.length,
        responsesCount: responses.length,
        correctRate,
        errorDistribution,
        scaffoldHistogram,
        perReactivo,
        reactivoOrder,
      });

      return {
        sessionsCount: sessions.length,
        responsesCount: responses.length,
        correctRate,
        errorDistribution,
        scaffoldHistogram,
        perReactivo,
        reactivoOrder,
        diagnosis,
        recentSessions: sessions.slice(0, 20).map((s) => ({
          id: s.id,
          alias: s.studentAlias,
          correctCount: s.correctCount,
          totalAnswered: s.totalAnswered,
          maxScaffoldUsed: s.maxScaffoldUsed,
          finishedAt: s.finishedAt,
          createdAt: s.createdAt,
        })),
      };
    }),
});
