/**
 * Sistema de créditos de IA — Monito gIA
 * Constantes compartidas entre backend y frontend.
 *
 * Filosofía ultra-rentable: reutilizar antes que generar.
 * Clonar de la biblioteca comunitaria es gratis; una variante con IA
 * cuesta menos que una generación original porque parte de trabajo
 * pedagógico ya validado por la comunidad.
 */
export const CREDIT_COSTS = {
  /** Generación original desde una semilla nueva */
  generation: 10,
  /** Variante isomorfa con IA a partir de una actividad de la biblioteca */
  variant: 6,
  /** Clonación directa desde la biblioteca (costo cero de tokens) */
  clone: 0,
} as const;

/** Créditos de cortesía al crear la cuenta (alcanza para 6 generaciones) */
export const WELCOME_CREDITS = 60;

export type CreditReason =
  | "welcome"
  | "generation"
  | "variant"
  | "clone"
  | "adjustment";

export const CREDIT_REASON_LABEL: Record<CreditReason, string> = {
  welcome: "Bono de bienvenida",
  generation: "Generación original con IA",
  variant: "Variante isomorfa con IA",
  clone: "Clonación desde la biblioteca",
  adjustment: "Ajuste manual",
};
