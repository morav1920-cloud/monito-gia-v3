import { z } from "zod";

/**
 * MonitoSchema v2 — contrato unificado de actividades Monito gIA.
 * Compartido entre backend (generación/persistencia) y frontend (renderizado).
 *
 * v3 (Matriz Polivalente): el contrato es polimórfico por `formatId`.
 * Cada arquetipo (quiz, flashcards, flowchart…) define su propio esquema
 * de contenido, todos compartiendo meta + mensajeCierre + runtime.
 */

/** Taxonomía de Errores Diagnósticos */
export const ERROR_CODES = ["CONCEPT", "PROC", "ATTN", "READ", "GUESS"] as const;
export const errorCodeSchema = z.enum(ERROR_CODES);
export type ErrorCode = (typeof ERROR_CODES)[number];

/** Andamiaje socrático de 5 peldaños (ZDP) */
export const SCAFFOLD_TYPES = [
  "activacion",
  "reencuadre",
  "estrategia",
  "descomposicion",
  "analogo_resuelto",
] as const;
export type ScaffoldType = (typeof SCAFFOLD_TYPES)[number];

export const scaffoldStepSchema = z.object({
  nivel: z.number().int().min(1).max(5),
  tipo: z.enum(SCAFFOLD_TYPES),
  pista: z.string().min(1),
});

export const optionSchema = z.object({
  id: z.string().min(1),
  texto: z.string().min(1),
  correcta: z.boolean(),
  /** Código diagnóstico: obligatorio en distractores, null en la correcta */
  errorCode: errorCodeSchema.nullable(),
  /** Explicación pedagógica del error (vista docente; se oculta al alumno) */
  diagnostico: z.string().nullable(),
});

export const feedbackItemSchema = z.object({
  codigo: errorCodeSchema,
  mensaje: z.string().min(1),
});

export const reactivoSchema = z.object({
  id: z.string().min(1),
  contexto: z.string(),
  enunciado: z.string().min(1),
  opciones: z.array(optionSchema).length(4),
  andamiaje: z.array(scaffoldStepSchema).length(5),
  feedbackPorError: z.array(feedbackItemSchema).min(3).max(5),
  feedbackCorrecto: z.string().min(1),
});

/** Lo que produce el motor generativo (sin metadatos de empaquetado) */
export const monitoContentSchema = z.object({
  meta: z.object({
    titulo: z.string().min(1),
    grado: z.number().int().min(3).max(6),
    asignatura: z.string().min(1),
    aprendizajeEsperado: z.string().min(1),
    zdpEstimada: z.enum(["baja", "media", "alta"]),
  }),
  reactivos: z.array(reactivoSchema).min(1).max(5),
  /** Cierre de sesión con mentalidad de crecimiento (Dweck) */
  mensajeCierre: z.string().min(1),
});

/** Contrato completo persistido y renderizable */
export const monitoActivitySchema = monitoContentSchema.extend({
  schemaVersion: z.literal("monito/v2"),
  formatId: z.string().default("multiple_choice"),
  runtime: z.object({
    offlineFirst: z.boolean(),
    presupuestoKb: z.number().int(),
  }),
});

/**
 * Contenido persistido de cualquier arquetipo. La forma base es
 * multiple_choice; los demás formatos sustituyen `reactivos` por su
 * propia colección (`tarjetas`, `pasos`…). Los tipos específicos se
 * obtienen con los esquemas por arquetipo de abajo.
 */
export interface StoredContent {
  schemaVersion: "monito/v2";
  formatId: string;
  meta: {
    titulo: string;
    grado: number;
    asignatura: string;
    aprendizajeEsperado: string;
    zdpEstimada: "baja" | "media" | "alta";
  };
  runtime: { offlineFirst: boolean; presupuestoKb: number };
  mensajeCierre: string;
  reactivos?: MonitoReactivo[];
  tarjetas?: FlashCard[];
  pasos?: FlowchartStep[];
  contexto?: string;
  instruccion?: string;
  erroresFrecuentes?: string[];
}

export type ScaffoldStep = z.infer<typeof scaffoldStepSchema>;
export type MonitoOption = z.infer<typeof optionSchema>;
export type MonitoReactivo = z.infer<typeof reactivoSchema>;
export type MonitoContent = z.infer<typeof monitoContentSchema>;
export type MonitoActivity = z.infer<typeof monitoActivitySchema>;

/* ============================================================
 * MATRIZ POLIVALENTE — arquetipos adicionales
 * ==========================================================*/

/** FLASHCARDS: tarjetas de estudio con autoevaluación */
export const flashCardSchema = z.object({
  id: z.string().min(1),
  frente: z.string().min(1),
  reverso: z.string().min(1),
  /** Pista socrática breve antes de voltear (no revela el reverso) */
  pista: z.string().min(1),
  /** Error típico que esta tarjeta corrige */
  errorTipico: errorCodeSchema.nullable(),
});

export const flashcardsContentSchema = z.object({
  meta: monitoContentSchema.shape.meta,
  tarjetas: z.array(flashCardSchema).min(4).max(12),
  mensajeCierre: z.string().min(1),
});

/** FLOWCHART: ordenar los pasos de una secuencia/proceso */
export const flowchartStepSchema = z.object({
  id: z.string().min(1),
  texto: z.string().min(1),
  /** Posición correcta en la secuencia (1-based) */
  orden: z.number().int().min(1),
  /** Pista socrática que guía a ubicar este paso sin decir su orden */
  pista: z.string().min(1),
});

export const flowchartContentSchema = z.object({
  meta: monitoContentSchema.shape.meta,
  contexto: z.string().min(1),
  instruccion: z.string().min(1),
  pasos: z.array(flowchartStepSchema).min(3).max(8),
  /** Errores de orden típicos (para feedback Dweck por par adyacente) */
  erroresFrecuentes: z.array(z.string().min(1)).min(1).max(4),
  mensajeCierre: z.string().min(1),
});

export type FlashCard = z.infer<typeof flashCardSchema>;
export type FlashcardsContent = z.infer<typeof flashcardsContentSchema>;
export type FlowchartStep = z.infer<typeof flowchartStepSchema>;
export type FlowchartContent = z.infer<typeof flowchartContentSchema>;

/** Registro de esquemas de contenido por arquetipo */
export const CONTENT_SCHEMAS = {
  multiple_choice: monitoContentSchema,
  flashcards: flashcardsContentSchema,
  flowchart: flowchartContentSchema,
} as const;

export type FormatId = keyof typeof CONTENT_SCHEMAS;

export function getContentSchema(formatId: string) {
  return CONTENT_SCHEMAS[formatId as FormatId] ?? monitoContentSchema;
}

/**
 * Extrae el "número de reactivos" homogéneo para vistas de lista,
 * sin importar el arquetipo.
 */
export function countReactivos(content: {
  reactivos?: unknown[];
  tarjetas?: unknown[];
  pasos?: unknown[];
}): number {
  return (
    content.reactivos?.length ??
    content.tarjetas?.length ??
    content.pasos?.length ??
    0
  );
}

export const ERROR_CODE_META: Record<
  ErrorCode,
  { nombre: string; descripcion: string }
> = {
  CONCEPT: {
    nombre: "Error conceptual",
    descripcion: "El alumno aún no consolida el concepto matemático subyacente.",
  },
  PROC: {
    nombre: "Error procedimental",
    descripcion: "Conoce el concepto, pero falla un paso del procedimiento.",
  },
  ATTN: {
    nombre: "Despiste",
    descripcion: "Error por atención o descuido, no por falta de conocimiento.",
  },
  READ: {
    nombre: "Comprensión lectora",
    descripcion: "No identificó qué se preguntaba en el enunciado.",
  },
  GUESS: {
    nombre: "Respuesta al azar",
    descripcion: "Patrón sin estrategia discernible; posible adivinanza.",
  },
};

export const SCAFFOLD_TYPE_META: Record<
  ScaffoldType,
  { nombre: string; descripcion: string }
> = {
  activacion: {
    nombre: "Activación",
    descripcion: "Reconecta con conocimientos previos del alumno.",
  },
  reencuadre: {
    nombre: "Reencuadre",
    descripcion: "Reformula el problema con otras palabras.",
  },
  estrategia: {
    nombre: "Estrategia",
    descripcion: "Sugiere un método de ataque, no el resultado.",
  },
  descomposicion: {
    nombre: "Descomposición",
    descripcion: "Parte el problema en sub-pasos manejables.",
  },
  analogo_resuelto: {
    nombre: "Análogo resuelto",
    descripcion: "Muestra un problema similar resuelto paso a paso.",
  },
};
