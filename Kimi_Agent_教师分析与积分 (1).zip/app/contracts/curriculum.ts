import { z } from "zod";

/**
 * Marco Curricular Oficial — Nueva Escuela Mexicana (Plan de Estudios 2022,
 * fase 4: 3° a 6° de primaria). Los 4 campos formativos estructuran la base
 * de conocimiento CONALITEG y el anclaje curricular del motor MGAA.
 */

export const CAMPOS_FORMATIVOS = [
  "lenguajes",
  "saberes_pensamiento",
  "etica_naturaleza",
  "humano_comunitario",
] as const;

export type CampoFormativo = (typeof CAMPOS_FORMATIVOS)[number];

export const campoFormativoSchema = z.enum(CAMPOS_FORMATIVOS);

/**
 * Matriz cromática oficial del Brand Book Monito gIA:
 * Azul = Tecnología/Conocimiento → Lenguajes (exploración y lectura)
 * Verde = Crecimiento/Aprendizaje → Saberes y Pensamiento Científico
 * Naranja = Creatividad/Soluciones → Ética, Naturaleza y Sociedades
 * Amarillo = Energía/Motivación → De lo Humano y lo Comunitario
 */
export const CAMPO_META: Record<
  CampoFormativo,
  { nombre: string; corto: string; color: string; bg: string }
> = {
  lenguajes: {
    nombre: "Lenguajes",
    corto: "Lenguajes",
    color: "#2E6FCE",
    bg: "#E2EEFB",
  },
  saberes_pensamiento: {
    nombre: "Saberes y Pensamiento Científico",
    corto: "Saberes",
    color: "#2F8F46",
    bg: "#E3F3E6",
  },
  etica_naturaleza: {
    nombre: "Ética, Naturaleza y Sociedades",
    corto: "Ética y Naturaleza",
    color: "#D9741A",
    bg: "#FBEEDD",
  },
  humano_comunitario: {
    nombre: "De lo Humano y lo Comunitario",
    corto: "Humano y Comunitario",
    color: "#B88A06",
    bg: "#FBF3D2",
  },
};

/** Colores del núcleo luminoso de Monito gIA (Brand Book §1) */
export type MonitoColor = "azul" | "verde" | "naranja" | "amarillo";

export const MONITO_PALETTE: Record<
  MonitoColor,
  { core: string; glass: string; deep: string }
> = {
  azul: { core: "#2E8FE8", glass: "#A8D4F5", deep: "#1B5FA8" },
  verde: { core: "#3CB55A", glass: "#A9E2B4", deep: "#227A3C" },
  naranja: { core: "#F08A24", glass: "#FCC58F", deep: "#B25E0F" },
  amarillo: { core: "#F2C230", glass: "#FBE38A", deep: "#A8810A" },
};

/** Campo formativo → color del núcleo de Monito */
export const CAMPO_MONITO_COLOR: Record<CampoFormativo, MonitoColor> = {
  lenguajes: "azul",
  saberes_pensamiento: "verde",
  etica_naturaleza: "naranja",
  humano_comunitario: "amarillo",
};

/** Anclaje curricular persistido en cada actividad */
export interface CurriculumAnchor {
  campoFormativo: CampoFormativo;
  /** Asignatura/área oficial (Matemáticas, Español, Historia…) */
  asignatura: string;
  /** Contenido oficial del programa (título del contenido) */
  contenido: string;
  /** Proceso de desarrollo de aprendizaje (PDA) oficial */
  pda: string;
  /** Confianza del cruce semántico-léxico (0 a 1) */
  score: number;
}

export const curriculumAnchorSchema = z.object({
  campoFormativo: campoFormativoSchema,
  asignatura: z.string(),
  contenido: z.string(),
  pda: z.string(),
  score: z.number().min(0).max(1),
});
